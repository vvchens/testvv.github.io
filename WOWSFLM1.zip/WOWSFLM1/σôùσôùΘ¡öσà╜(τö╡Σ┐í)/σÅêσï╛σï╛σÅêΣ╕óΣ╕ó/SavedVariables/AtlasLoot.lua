
AtlasLootCharDB = {
	["QuickLooks"] = {
	},
	["AtlasLootVersion"] = "40604",
	["WishList"] = {
	},
	["SearchResult"] = {
	},
}
