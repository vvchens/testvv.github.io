
BigFoot_Frames = {
	["MyBankFrame"] = {
		["Y"] = 735,
		["X"] = 41,
		["W"] = 480,
		["H"] = 313,
	},
	["MyInventoryAnchorFrame"] = {
		["Y"] = 685,
		["X"] = 597,
		["W"] = 1,
		["H"] = 1,
	},
	["SpellTimerMainFrame"] = {
		["Y"] = 453,
		["X"] = 783,
		["W"] = 1,
		["H"] = 1,
	},
}
