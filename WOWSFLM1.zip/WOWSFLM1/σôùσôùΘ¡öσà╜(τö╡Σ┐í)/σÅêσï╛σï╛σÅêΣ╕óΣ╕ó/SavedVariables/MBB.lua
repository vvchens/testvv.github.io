
MBB_Exclude = {
}
MBB_Options = {
	["CollapseTimeout"] = 2,
	["EnableMBB"] = true,
	["AttachToMinimap"] = 1,
	["AltExpandDirection"] = 4,
	["MaxButtonsPerLine"] = 0,
	["ButtonPos"] = {
		2, -- [1]
		-118, -- [2]
	},
	["ExpandDirection"] = 1,
}
