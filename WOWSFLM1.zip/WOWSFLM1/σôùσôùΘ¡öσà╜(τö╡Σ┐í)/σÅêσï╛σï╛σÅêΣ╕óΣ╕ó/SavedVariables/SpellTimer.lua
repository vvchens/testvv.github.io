
SpellTimer_Config = {
	["WarningTime"] = 5,
	["ShowName"] = 1,
	["ShowProgressBar"] = 1,
	["Scale"] = 0.8,
	["EnabledTest"] = 1,
	["HideAllWhenLeaveCombat"] = 1,
}
