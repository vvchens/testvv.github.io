
AtlasOptions = {
	["AtlasScale"] = 1,
	["AtlasSortBy"] = 1,
	["AtlasButtonShown"] = true,
	["AtlasVersion"] = "1.12.0",
	["AtlasButtonPosition"] = 356,
	["AtlasButtonRadius"] = 78,
	["AtlasAcronyms"] = true,
	["AtlasType"] = 3,
	["AtlasCoords"] = false,
	["AtlasCtrl"] = false,
	["AtlasAlpha"] = 1,
	["AtlasRightClick"] = false,
	["AtlasZone"] = 1,
	["AtlasAutoSelect"] = false,
	["AtlasClamped"] = true,
	["AtlasLocked"] = false,
}
