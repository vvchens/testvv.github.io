
AtlasLootCharDB = {
	["QuickLooks"] = {
	},
	["SearchResult"] = {
	},
	["WishList"] = {
	},
	["AtlasLootVersion"] = "40604",
}
