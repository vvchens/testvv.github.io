
AtlasOptions = {
	["AtlasScale"] = 1,
	["AtlasSortBy"] = 1,
	["AtlasLocked"] = false,
	["AtlasClamped"] = true,
	["AtlasAlpha"] = 1,
	["AtlasZone"] = 3,
	["AtlasAcronyms"] = true,
	["AtlasType"] = 1,
	["AtlasButtonShown"] = true,
	["AtlasVersion"] = "1.12.0",
	["AtlasButtonPosition"] = 356,
	["AtlasRightClick"] = false,
	["AtlasButtonRadius"] = 78,
	["AtlasAutoSelect"] = false,
	["AtlasCtrl"] = false,
	["AtlasCoords"] = false,
}
