
MBB_Exclude = {
}
MBB_Options = {
	["CollapseTimeout"] = 2,
	["EnableMBB"] = true,
	["AttachToMinimap"] = 1,
	["ExpandDirection"] = 1,
	["MaxButtonsPerLine"] = 0,
	["ButtonPos"] = {
		2, -- [1]
		-118, -- [2]
	},
	["AltExpandDirection"] = 4,
}
