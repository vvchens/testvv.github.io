
BigFoot_Config = {
	["MapToolkit"] = {
		["EnableInstanceMaps"] = 1,
	},
	["SpellHelper"] = {
		["DisableQuestFading"] = 1,
	},
	["BUnitFrame"] = {
		["FocusMode"] = "普通模式",
		["EnableCastingShining"] = 1,
		["EnableCastingIcon"] = 1,
		["EnableTargetTargetTarget"] = 0,
		["EnableBUnitFrame"] = 1,
		["EnableTargetTarget"] = 0,
	},
	["BigFootBot"] = {
		["EnableBigFoot"] = 1,
	},
	["MapPlus"] = {
		["EnableMapPlus"] = 1,
		["AcceptMapNote"] = 1,
	},
	["RaidToolkit"] = {
		["EnableGrid"] = 0,
		["EnableDecursive"] = 0,
		["EnableRecount"] = 0,
		["EnableThreat"] = 0,
		["EnableoRA2"] = 0,
		["EnableDBM"] = 0,
	},
	["QuestEnhancement"] = {
		["ShowQuestLevel"] = 1,
	},
	["InfoStat"] = {
		["DisplayItemQulity"] = 1,
		["DisplayDurability"] = 0,
		["EnableMerInspect"] = 1,
		["BigFoot Rating"] = 1,
	},
	["RepairHelper"] = {
		["AutoRepairDurability"] = 0,
		["RepairHelper_UseGuildMoney"] = 1,
		["RepairHelper_RepairAll"] = 0,
		["EnableRepairHelper"] = 0,
	},
	["ActionButton"] = {
		["EnableCooldownCount"] = 0,
		["ShineType"] = "标准",
		["ShowTargetCooldown"] = 0,
		["EnableDistanceAlert"] = 1,
	},
	["SellerHelper"] = {
		["AutoSellPoor"] = 0,
		["EnableSellerHelper"] = 1,
		["KeepMiningTool"] = 1,
		["KeepDarkMoonItem"] = 1,
	},
	["HandyToolkit"] = {
		["EnableFasyFocus"] = 1,
	},
	["BagManagement"] = {
		["EnabelOpenAllBagsOnBank"] = 1,
		["EnabelOpenAllBagsOnTrading"] = 1,
		["ShowFreeSlots"] = 1,
		["EnablePurchaseConfirm"] = 1,
		["EnabelOpenAllBagsOnMerchant"] = 1,
	},
	["BagIntegration"] = {
		["EnableMyInventory"] = 1,
		["EnableMyInventoryViewOther"] = 0,
		["EnableMyBank"] = 1,
		["Enable_PUI"] = 1,
		["ReverseMode"] = 0,
	},
	["PartyToolkit"] = {
		["EnableClique"] = 0,
		["EnablePartyAssist"] = 0,
		["LiteTips"] = 1,
		["8Buttons"] = 0,
	},
	["InfoBox"] = {
		["EnableInfoBoxV2"] = 0,
	},
	["ArenaMod"] = {
		["EnableProximo"] = 1,
	},
	["BuffMaster"] = {
		["EnablePartyBuffer"] = 1,
		["BuffMasterShowTimeLeft"] = 1,
	},
	["MailMod"] = {
		["EnableMailMod"] = 1,
	},
	["BigFootQuest"] = {
		["EnableBigFootQuest"] = 1,
	},
	["BigFootBar"] = {
		["HideTab"] = 0,
		["HideGrid"] = 0,
		["Enable_BigFootBar"] = 0,
	},
	["InfoEnhancement"] = {
		["EnablePlayerLink"] = 1,
		["EnableQuickCompare"] = 1,
	},
	["BigFootGadget"] = {
		["EnableBigFootClock"] = 1,
		["EnableBigFootMBB"] = 1,
		["EnableBigFootGPS"] = 1,
		["HideDefaultClock"] = 1,
	},
	["TrinketMenu"] = {
		["EnableTrinketMenu"] = 0,
	},
	["QuickLoot"] = {
		["EnableQuickLoot"] = 1,
		["QuickLootAutoHide"] = 0,
	},
	["SpellTimer"] = {
		["EnableSpellTimer"] = 1,
	},
	["PortraitEnhancement"] = {
		["EnableTargetClassInfo"] = 1,
		["EnablePartyPor"] = 1,
		["Show3DPortrait"] = 0,
		["EnablePorEnhance"] = 1,
		["EnableColorize"] = 1,
		["ShowPartyText"] = 1,
		["ShowXPBar"] = 1,
	},
	["MobHealth"] = {
		["TransparentMode"] = 0,
		["ShowHealthPercentv2"] = 0,
		["ShowManaPoint"] = 1,
		["MobHealthEnable"] = 1,
		["ShowHealthPPT"] = 1,
	},
	["BFTT"] = {
		["BigFootTooltipFade"] = "是",
		["BigFootTooltipCorpse"] = "显示",
		["BigFootTooltipPositionY"] = -25,
		["BigFootTooltipPvP"] = "隐藏",
		["BigFootTooltipReduce"] = "显示",
		["EnableBFTooltip"] = 1,
		["BigFootTooltipToT"] = "显示",
		["BigFootTooltipTalent"] = "显示",
		["BigFootTooltipPositionX"] = -20,
		["BigFootTooltipPosition"] = "鼠标",
	},
	["Item Info"] = {
		["EnableItemLevel"] = 1,
		["EnableStackCount"] = 1,
		["EnableUseInfo"] = 1,
		["EnableItemInfo"] = 1,
		["EnableAuctionInfo"] = 1,
		["EnableGemInfo"] = 1,
		["EnableSellValue"] = 1,
		["EnableAuctionHelper"] = 1,
	},
	["ScreenMark"] = {
		["ScreenMark_EnableCinematicMode"] = 1,
		["ScreenMark_EnableSign"] = 0,
		["ScreenMark_EnablePhotoMode"] = 1,
	},
	["CombatIndicator"] = {
		["EnableCombatLeave"] = 1,
		["EnableCombatIndicator"] = 1,
		["EnableComboPoint"] = 1,
		["EnableShowSpell"] = 1,
		["EnableSCT"] = 0,
	},
	["AutoEquip"] = {
		["EnableAutoEquip"] = 1,
		["EnableAdvancedMode"] = 0,
		["EnableAutoHide"] = 0,
	},
	["ChatEnhancement"] = {
		["EnableScrollChatFrame"] = 1,
		["EnableBubbleChat"] = 1,
	},
}
BigFoot_Error = {
}
