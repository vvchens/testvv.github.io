
FocusFrameOptions = {
	["scale"] = 1,
	["hidewhendead"] = true,
}
