
BUnitFrame_Config = {
	["casting_flash"] = true,
	["version"] = 2.7,
	["focus"] = {
		["enabled"] = false,
		["theme"] = "vertical",
	},
	["casting_icon"] = true,
	["ttt"] = {
		["enabled"] = false,
		["theme"] = "classical",
	},
	["tt"] = {
		["enabled"] = false,
		["theme"] = "classical",
	},
}
