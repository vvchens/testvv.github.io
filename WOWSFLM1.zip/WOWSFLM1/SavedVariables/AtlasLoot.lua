
AtlasLootOptions = nil
AtlasLootFuDB = {
	["profiles"] = {
		["Default"] = {
			["detachedTooltip"] = {
				["fontSizePercent"] = 1,
			},
		},
	},
}
AtlasLootDB = {
	["profiles"] = {
		["Default"] = {
			["AtlasLootVersion"] = "40604",
		},
	},
}
