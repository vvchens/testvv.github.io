
MyBankProfile = {
	["又勾勾又丢丢|哗哗魔兽(电信)"] = {
		["BagView"] = 1,
		["Bag6"] = {
			{
				["i"] = "INV_Elemental_Mote_Shadow01",
				["name"] = "暗影微粒",
				["c"] = 14,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:22577:0:0:0:0:0:0:0|h[暗影微粒]|h|r",
				["item"] = "22577:0:0:0:0:0:0:0",
			}, -- [1]
			{
				["i"] = "INV_Misc_Herb_19",
				["name"] = "火焰花",
				["c"] = 2,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:4625:0:0:0:0:0:0:0|h[火焰花]|h|r",
				["item"] = "4625:0:0:0:0:0:0:0",
			}, -- [2]
			{
				["i"] = "INV_Misc_Herb_08",
				["name"] = "卡德加的胡须",
				["c"] = 3,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:3358:0:0:0:0:0:0:0|h[卡德加的胡须]|h|r",
				["item"] = "3358:0:0:0:0:0:0:0",
			}, -- [3]
			{
				["i"] = "INV_Misc_Herb_15",
				["name"] = "金棘草",
				["c"] = 23,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:3821:0:0:0:0:0:0:0|h[金棘草]|h|r",
				["item"] = "3821:0:0:0:0:0:0:0",
			}, -- [4]
			{
				["i"] = "INV_Misc_Root_02",
				["name"] = "活根草",
				["c"] = 4,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:3357:0:0:0:0:0:0:0|h[活根草]|h|r",
				["item"] = "3357:0:0:0:0:0:0:0",
			}, -- [5]
			{
				["i"] = "INV_Misc_Flower_01",
				["name"] = "野钢花",
				["c"] = 2,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:3355:0:0:0:0:0:0:0|h[野钢花]|h|r",
				["item"] = "3355:0:0:0:0:0:0:0",
			}, -- [6]
			{
				["i"] = "INV_Misc_Herb_12",
				["name"] = "枯叶草",
				["c"] = 6,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:3818:0:0:0:0:0:0:0|h[枯叶草]|h|r",
				["item"] = "3818:0:0:0:0:0:0:0",
			}, -- [7]
			{
				["i"] = "INV_Misc_Herb_14",
				["name"] = "盲目草",
				["c"] = 38,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:8839:0:0:0:0:0:0:0|h[盲目草]|h|r",
				["item"] = "8839:0:0:0:0:0:0:0",
			}, -- [8]
			{
				["i"] = "INV_Misc_Herb_Netherbloom",
				["name"] = "虚空花",
				["c"] = 3,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:22791:0:0:0:0:0:0:0|h[虚空花]|h|r",
				["item"] = "22791:0:0:0:0:0:0:0",
			}, -- [9]
			{
				["i"] = "INV_Misc_Herb_Dreamingglory",
				["name"] = "梦露花",
				["c"] = 5,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:22786:0:0:0:0:0:0:0|h[梦露花]|h|r",
				["item"] = "22786:0:0:0:0:0:0:0",
			}, -- [10]
			{
				["i"] = "INV_Misc_Flower_03",
				["name"] = "未鉴定过的植物",
				["c"] = 1,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:24401:0:0:0:0:0:0:0|h[未鉴定过的植物]|h|r",
				["item"] = "24401:0:0:0:0:0:0:0",
			}, -- [11]
			{
				["i"] = "INV_Misc_Herb_18",
				["name"] = "太阳草",
				["c"] = 2,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:8838:0:0:0:0:0:0:0|h[太阳草]|h|r",
				["item"] = "8838:0:0:0:0:0:0:0",
			}, -- [12]
			{
				["i"] = "INV_Misc_Herb_19",
				["name"] = "红色木槿",
				["c"] = 3,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:24246:0:0:0:0:0:0:0|h[红色木槿]|h|r",
				["item"] = "24246:0:0:0:0:0:0:0",
			}, -- [13]
			{
				["i"] = "INV_Misc_Gem_Pearl_02",
				["name"] = "裂纹的珍珠",
				["c"] = 3,
				["color"] = "ff1eff00",
				["itemlink"] = "|cff1eff00|Hitem:24478:0:0:0:0:0:0:0|h[裂纹的珍珠]|h|r",
				["item"] = "24478:0:0:0:0:0:0:0",
			}, -- [14]
			["i"] = "INV_Misc_Bag_11",
			["s"] = 14,
			["color"] = "ffffffff",
			["name"] = "巨魔皮包",
			["itemlink"] = "|cffffffff|Hitem:1685:0:0:0:0:0:0:0|h[巨魔皮包]|h|r",
			["item"] = "1685:0:0:0:0:0:0:0",
		},
		["Columns"] = 12,
		["HighlightItems"] = 1,
		["money"] = 5830313,
		["Bags"] = 2,
		["Scale"] = 1,
		["ReplaceBank"] = 1,
		["Bag5"] = {
			{
				["i"] = "INV_Misc_Herb_04",
				["name"] = "雨燕草",
				["c"] = 5,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2452:0:0:0:0:0:0:0|h[雨燕草]|h|r",
				["item"] = "2452:0:0:0:0:0:0:0",
			}, -- [1]
			{
				["i"] = "INV_Misc_Herb_01",
				["name"] = "跌打草",
				["c"] = 23,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2453:0:0:0:0:0:0:0|h[跌打草]|h|r",
				["item"] = "2453:0:0:0:0:0:0:0",
			}, -- [2]
			{
				["i"] = "INV_Misc_Root_01",
				["name"] = "布瑞尔索恩",
				["c"] = 11,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2450:0:0:0:0:0:0:0|h[布瑞尔索恩]|h|r",
				["item"] = "2450:0:0:0:0:0:0:0",
			}, -- [3]
			{
				["i"] = "INV_Misc_Herb_IceCap",
				["name"] = "冰盖草",
				["c"] = 11,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:13467:0:0:0:0:0:0:0|h[冰盖草]|h|r",
				["item"] = "13467:0:0:0:0:0:0:0",
			}, -- [4]
			{
				["i"] = "INV_Elemental_Primal_Nether",
				["name"] = "源生虚空",
				["c"] = 1,
				["color"] = "ff0070dd",
				["itemlink"] = "|cff0070dd|Hitem:23572:0:0:0:0:0:0:0|h[源生虚空]|h|r",
				["item"] = "23572:0:0:0:0:0:0:0",
			}, -- [5]
			{
				["i"] = "INV_Scroll_05",
				["name"] = "图鉴：高能黄晶玉",
				["c"] = 1,
				["color"] = "ff0070dd",
				["itemlink"] = "|cff0070dd|Hitem:24214:0:0:0:0:0:0:0|h[图鉴：高能黄晶玉]|h|r",
				["item"] = "24214:0:0:0:0:0:0:0",
			}, -- [6]
			{
				["i"] = "INV_Scroll_04",
				["name"] = "图鉴：黄色之星",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40292:0:0:0:0:0:0:0|h[图鉴：黄色之星]|h|r",
				["item"] = "40292:0:0:0:0:0:0:0",
			}, -- [7]
			{
				["i"] = "jinengsuipian",
				["name"] = "|cFF00FFFF紧那罗残卷|cFFFFCCCC八部之|cFFFF00CC七",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40067:0:0:0:0:0:0:0|h[|cFF00FFFF紧那罗残卷|cFFFFCCCC八部之|cFFFF00CC七]|h|r",
				["item"] = "40067:0:0:0:0:0:0:0",
			}, -- [8]
			{
				["i"] = "INV_Misc_Apexis_Shard",
				["name"] = "神油碎片",
				["c"] = 107,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40011:0:0:0:0:0:0:0|h[神油碎片]|h|r",
				["item"] = "40011:0:0:0:0:0:0:0",
			}, -- [9]
			{
				["i"] = "File00000558",
				["name"] = "|cFFFF00CC会员卡",
				["c"] = 146,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40008:0:0:0:0:0:0:0|h[|cFFFF00CC会员卡]|h|r",
				["item"] = "40008:0:0:0:0:0:0:0",
			}, -- [10]
			{
				["i"] = "File00000585",
				["name"] = "元宝",
				["c"] = 211,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40015:0:0:0:0:0:0:0|h[元宝]|h|r",
				["item"] = "40015:0:0:0:0:0:0:0",
			}, -- [11]
			{
				["i"] = "File00000585",
				["name"] = "元宝",
				["c"] = 250,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40015:0:0:0:0:0:0:0|h[元宝]|h|r",
				["item"] = "40015:0:0:0:0:0:0:0",
			}, -- [12]
			{
				["i"] = "INV_Qiraj_JewelEncased",
				["name"] = "武器精华",
				["c"] = 20,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40012:0:0:0:0:0:0:0|h[武器精华]|h|r",
				["item"] = "40012:0:0:0:0:0:0:0",
			}, -- [13]
			{
				["i"] = "INV_Qiraj_JewelEngraved",
				["name"] = "饰品精华",
				["c"] = 10,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40013:0:0:0:0:0:0:0|h[饰品精华]|h|r",
				["item"] = "40013:0:0:0:0:0:0:0",
			}, -- [14]
			{
				["i"] = "Spell_Holy_ChampionsBond",
				["name"] = "公正徽章",
				["c"] = 17,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[公正徽章]|h|r",
				["item"] = "29434:0:0:0:0:0:0:0",
			}, -- [15]
			{
				["i"] = "INV_Spear_06",
				["name"] = "盘牙武器",
				["c"] = 11,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:24368:0:0:0:0:0:0:0|h[盘牙武器]|h|r",
				["item"] = "24368:0:0:0:0:0:0:0",
			}, -- [16]
			["i"] = "INV_Misc_Bag_08",
			["s"] = 16,
			["color"] = "ff1eff00",
			["name"] = "旅行者的背包",
			["itemlink"] = "|cff1eff00|Hitem:4500:0:0:0:0:0:0:0|h[旅行者的背包]|h|r",
			["item"] = "4500:0:0:0:0:0:0:0",
		},
		["Bank"] = {
			{
				["i"] = "INV_Shirt_GuildTabard_01",
				["name"] = "初级·战袍",
				["c"] = 1,
				["color"] = "ff0070dd",
				["itemlink"] = "|cff0070dd|Hitem:40041:0:0:0:0:0:40037:0|h[初级·战袍]|h|r",
				["item"] = "40041:0:0:0:0:0:40037:0",
			}, -- [1]
			{
				["i"] = "INV_Shirt_GuildTabard_01",
				["name"] = "初级·战袍",
				["c"] = 1,
				["color"] = "ff0070dd",
				["itemlink"] = "|cff0070dd|Hitem:40041:0:0:0:0:0:40037:0|h[初级·战袍]|h|r",
				["item"] = "40041:0:0:0:0:0:40037:0",
			}, -- [2]
			{
				["i"] = "INV_Weapon_Shortblade_37",
				["name"] = "帝殒|cFF33FF33新手",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:122802:0:0:0:0:0:0:0|h[帝殒|cFF33FF33新手]|h|r",
				["item"] = "122802:0:0:0:0:0:0:0",
			}, -- [3]
			{
				["i"] = "INV_Weapon_Shortblade_37",
				["name"] = "帝殒|cFF33FF33新手",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:122802:0:0:0:0:0:0:0|h[帝殒|cFF33FF33新手]|h|r",
				["item"] = "122802:0:0:0:0:0:0:0",
			}, -- [4]
			{
				["i"] = "INV_Shirt_Green_01",
				["name"] = "初级·衬衣",
				["c"] = 1,
				["color"] = "ff0070dd",
				["itemlink"] = "|cff0070dd|Hitem:40031:0:0:0:0:0:40026:0|h[初级·衬衣]|h|r",
				["item"] = "40031:0:0:0:0:0:40026:0",
			}, -- [5]
			{
				["i"] = "INV_Scroll_08",
				["name"] = "|cFF00FFFF九阴真经残卷",
				["c"] = 4,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40072:0:0:0:0:0:0:0|h[|cFF00FFFF九阴真经残卷]|h|r",
				["item"] = "40072:0:0:0:0:0:0:0",
			}, -- [6]
			{
				["i"] = "INV_Scroll_08",
				["name"] = "|cFF00FFFF玉女心经残卷",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40074:0:0:0:0:0:0:0|h[|cFF00FFFF玉女心经残卷]|h|r",
				["item"] = "40074:0:0:0:0:0:0:0",
			}, -- [7]
			{
				["i"] = "jinengsuipian",
				["name"] = "|cFF00FFFF天众残卷|cFFFFCCCC八部之|cFFFF00CC一",
				["c"] = 2,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40061:0:0:0:0:0:0:0|h[|cFF00FFFF天众残卷|cFFFFCCCC八部之|cFFFF00CC一]|h|r",
				["item"] = "40061:0:0:0:0:0:0:0",
			}, -- [8]
			{
				["i"] = "jinengsuipian",
				["name"] = "|cFF00FFFF龙众残卷|cFFFFCCCC八部之|cFFFF00CC二",
				["c"] = 2,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40062:0:0:0:0:0:0:0|h[|cFF00FFFF龙众残卷|cFFFFCCCC八部之|cFFFF00CC二]|h|r",
				["item"] = "40062:0:0:0:0:0:0:0",
			}, -- [9]
			{
				["i"] = "jinengsuipian",
				["name"] = "|cFF00FFFF夜叉残卷|cFFFFCCCC八部之|cFFFF00CC三",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40063:0:0:0:0:0:0:0|h[|cFF00FFFF夜叉残卷|cFFFFCCCC八部之|cFFFF00CC三]|h|r",
				["item"] = "40063:0:0:0:0:0:0:0",
			}, -- [10]
			{
				["i"] = "jinengsuipian",
				["name"] = "|cFF00FFFF摩呼罗迦残卷|cFFFFCCCC八部之|cFFFF00CC八",
				["c"] = 1,
				["color"] = "ffa335ee",
				["itemlink"] = "|cffa335ee|Hitem:40068:0:0:0:0:0:0:0|h[|cFF00FFFF摩呼罗迦残卷|cFFFFCCCC八部之|cFFFF00CC八]|h|r",
				["item"] = "40068:0:0:0:0:0:0:0",
			}, -- [11]
			{
				["i"] = "INV_Potion_54",
				["name"] = "特效治疗药水",
				["c"] = 1,
				["color"] = "ffffffff",
				["d"] = {
					["e"] = 1,
					["d"] = 0,
					["s"] = 0,
				},
				["itemlink"] = "|cffffffff|Hitem:13446:0:0:0:0:0:0:0|h[特效治疗药水]|h|r",
				["item"] = "13446:0:0:0:0:0:0:0",
			}, -- [12]
			{
				["i"] = "INV_Misc_Herb_Felweed",
				["name"] = "魔草",
				["c"] = 6,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:22785:0:0:0:0:0:0:0|h[魔草]|h|r",
				["item"] = "22785:0:0:0:0:0:0:0",
			}, -- [13]
			{
				["i"] = "INV_Potion_147",
				["name"] = "一块钱的印度神油",
				["c"] = 2,
				["color"] = "ff1eff00",
				["d"] = {
					["e"] = 1,
					["d"] = 0,
					["s"] = 0,
				},
				["itemlink"] = "|cff1eff00|Hitem:40022:0:0:0:0:0:0:0|h[一块钱的印度神油]|h|r",
				["item"] = "40022:0:0:0:0:0:0:0",
			}, -- [14]
			{
				["i"] = "INV_Potion_146",
				["name"] = "一百块的印度神油",
				["c"] = 1,
				["color"] = "ff0070dd",
				["d"] = {
					["e"] = 1,
					["d"] = 0,
					["s"] = 0,
				},
				["itemlink"] = "|cff0070dd|Hitem:40023:0:0:0:0:0:0:0|h[一百块的印度神油]|h|r",
				["item"] = "40023:0:0:0:0:0:0:0",
			}, -- [15]
			{
				["i"] = "INV_Misc_Herb_Terrocone",
				["name"] = "泰罗果",
				["c"] = 5,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:22789:0:0:0:0:0:0:0|h[泰罗果]|h|r",
				["item"] = "22789:0:0:0:0:0:0:0",
			}, -- [16]
			{
				["i"] = "INV_Fabric_Netherweave",
				["name"] = "灵纹布",
				["c"] = 250,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:21877:0:0:0:0:0:0:0|h[灵纹布]|h|r",
				["item"] = "21877:0:0:0:0:0:0:0",
			}, -- [17]
			{
				["i"] = "INV_Fabric_Netherweave",
				["name"] = "灵纹布",
				["c"] = 250,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:21877:0:0:0:0:0:0:0|h[灵纹布]|h|r",
				["item"] = "21877:0:0:0:0:0:0:0",
			}, -- [18]
			{
				["i"] = "INV_Fabric_PurpleFire_01",
				["name"] = "符文布",
				["c"] = 95,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:14047:0:0:0:0:0:0:0|h[符文布]|h|r",
				["item"] = "14047:0:0:0:0:0:0:0",
			}, -- [19]
			{
				["i"] = "INV_Misc_Herb_MountainSilverSage",
				["name"] = "山鼠草",
				["c"] = 7,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:13465:0:0:0:0:0:0:0|h[山鼠草]|h|r",
				["item"] = "13465:0:0:0:0:0:0:0",
			}, -- [20]
			{
				["i"] = "INV_Ore_Copper_01",
				["name"] = "铜矿石",
				["c"] = 39,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2770:0:0:0:0:0:0:0|h[铜矿石]|h|r",
				["item"] = "2770:0:0:0:0:0:0:0",
			}, -- [21]
			{
				["i"] = "INV_Stone_06",
				["name"] = "劣质的石头",
				["c"] = 14,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2835:0:0:0:0:0:0:0|h[劣质的石头]|h|r",
				["item"] = "2835:0:0:0:0:0:0:0",
			}, -- [22]
			{
				["i"] = "INV_Stone_09",
				["name"] = "粗糙的石头",
				["c"] = 3,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2836:0:0:0:0:0:0:0|h[粗糙的石头]|h|r",
				["item"] = "2836:0:0:0:0:0:0:0",
			}, -- [23]
			{
				["i"] = "INV_Stone_12",
				["name"] = "沉重的石头",
				["c"] = 1,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2838:0:0:0:0:0:0:0|h[沉重的石头]|h|r",
				["item"] = "2838:0:0:0:0:0:0:0",
			}, -- [24]
			{
				["i"] = "INV_Jewelry_Talisman_03",
				["name"] = "魔皇草",
				["c"] = 18,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:785:0:0:0:0:0:0:0|h[魔皇草]|h|r",
				["item"] = "785:0:0:0:0:0:0:0",
			}, -- [25]
			{
				["i"] = "INV_Misc_Flower_02",
				["name"] = "宁神花",
				["c"] = 27,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2447:0:0:0:0:0:0:0|h[宁神花]|h|r",
				["item"] = "2447:0:0:0:0:0:0:0",
			}, -- [26]
			{
				["i"] = "INV_Misc_Herb_10",
				["name"] = "银叶草",
				["c"] = 30,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:765:0:0:0:0:0:0:0|h[银叶草]|h|r",
				["item"] = "765:0:0:0:0:0:0:0",
			}, -- [27]
			{
				["i"] = "INV_Misc_Herb_07",
				["name"] = "地根草",
				["c"] = 11,
				["color"] = "ffffffff",
				["itemlink"] = "|cffffffff|Hitem:2449:0:0:0:0:0:0:0|h[地根草]|h|r",
				["item"] = "2449:0:0:0:0:0:0:0",
			}, -- [28]
		},
		["HighlightBags"] = 1,
		["ShowPlayers"] = 1,
		["Graphics"] = 1,
		["Background"] = 1,
		["Freeze"] = 0,
	},
	["好吃不如饺子|哗哗魔兽(电信)"] = {
		["BagView"] = 1,
		["HighlightItems"] = 1,
		["Scale"] = 1,
		["ReplaceBank"] = 1,
		["money"] = 968357,
		["HighlightBags"] = 1,
		["Graphics"] = 1,
		["Columns"] = 12,
		["Background"] = 1,
		["ShowPlayers"] = 1,
		["Freeze"] = 0,
	},
}
