
CombatIndicator_Config = {
	["ShowComboPoint"] = true,
	["EnableCombatIndicator"] = 1,
	["LeaveCombat_Alert"] = true,
	["ShowSpell"] = true,
}
