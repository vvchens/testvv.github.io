
ItemInfo_Config = {
	["rname"] = {
	},
	["bidprice"] = {
	},
}
II_Temp_NonValue = {
}
