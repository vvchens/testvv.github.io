
MapNoteInfo = {
	["Netherstorm"] = {
	},
	["Elwynn"] = {
	},
	["Hellfire"] = {
	},
	["BlastedLands"] = {
	},
	["TerokkarForest"] = {
	},
	["Winterspring"] = {
	},
	["Westfall"] = {
	},
	["Zangarmarsh"] = {
	},
	["Stranglethorn"] = {
	},
	["Wetlands"] = {
	},
}
