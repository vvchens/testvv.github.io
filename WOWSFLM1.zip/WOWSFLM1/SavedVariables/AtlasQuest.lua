
AtlasQuest_Options = {
	["好吃不如饺子"] = {
		["ShownSide"] = "Right",
		["AtlasAutoShow"] = 1,
		["NoQuerySpam"] = "yes",
	},
	["Version"] = "4.1.2",
	["又勾勾又丢丢"] = {
		["ShownSide"] = "Right",
		["AtlasAutoShow"] = 1,
		["NoQuerySpam"] = "yes",
	},
}
