
BigFootGadget_Config = {
	["clock"] = {
		["theme"] = "clock",
	},
}
