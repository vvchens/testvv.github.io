
BFTT_Config = {
	["Corpse"] = 1,
	["Guild"] = 1,
	["Talent"] = 1,
	["TOT"] = 1,
	["Fade"] = 1,
	["PositionY"] = -25,
	["PositionX"] = -20,
	["Anchor"] = 2,
	["AR"] = 1,
	["PVP"] = 2,
}
