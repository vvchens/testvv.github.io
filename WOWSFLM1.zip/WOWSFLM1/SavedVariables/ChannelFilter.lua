
ChannelFilter_Config = {
	["Enabled"] = 1,
	["IgnoreWords"] = {
		"金币", -- [1]
		"代练", -- [2]
		"金库", -- [3]
		"WWW%.", -- [4]
		"www%.", -- [5]
		["n"] = 5,
	},
	["AutoIgnorePlayer"] = 1,
	["IgnorePlayer"] = {
	},
}
