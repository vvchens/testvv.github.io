
MozzFullWorldMap = {
	["Enabled"] = 1,
	["transparency"] = 1,
	["Errata"] = {
	},
	["version"] = "v3.30.20400",
	["colorStyle"] = 0,
}
