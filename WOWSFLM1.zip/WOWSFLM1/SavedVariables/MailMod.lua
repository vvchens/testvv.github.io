
MailMod_Config = {
	["ContactList"] = {
		["哗哗魔兽(电信)"] = {
		},
	},
}
